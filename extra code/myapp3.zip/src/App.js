import React, { Component } from 'react'
import Student from './Student'
export default class App extends Component {

  state = {
    students: [],
    si: ''
  }

  onChangeHand = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }

  componentDidMount(){
    const url = "https://ssimpt-c6ab3.firebaseio.com/Students.json";
    fetch(url)
    .then(resp => {return resp.json()})
    .then(resp => {
      console.log(resp);
      this.setState({
        students: resp
      })
      var studentsStr = JSON.stringify(resp)
      localStorage.setItem("studentsStr", studentsStr);
    })    
    .catch(err => {
      var studentsStr = localStorage.getItem("studentsStr");
      var students = JSON.parse(studentsStr);
      this.setState({
        students: students
      })
      console.log(err);
    })
  }

  render() {

    const filteredList = [];
    this.state.students.forEach(s1 => {
      const siRegex = new RegExp(this.state.si, "i");
      if(s1.Name.search(siRegex)!==-1 ||  s1.PN.search(siRegex)!==-1){
        filteredList.push(s1)
      }
    })

    return (
      <div>
        <h1>Student Database!</h1>
        <input 
        name="si" 
        value={this.state.si}
        onChange={this.onChangeHand}
        />

        <div className="row">
        {
          filteredList.map(s1 => <div className="col-sm-4"><Student {...s1} /></div>)
        }
        </div>
      </div>
    )
  }
}

import React, { Component } from 'react'

export default class Main2 extends Component {
    render() {
        return (
            <div>
                <h1>I am new!!</h1>
            </div>
        )
    }
}

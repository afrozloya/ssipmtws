import React, { Component } from 'react'

export default class App2 extends Component {
    render() {
        return (
            <div>
               <h1>New!!!</h1> 
            </div>
        )
    }
}

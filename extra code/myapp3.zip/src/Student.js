import React from 'react'
import * as classes from './student.module.css'

export default function Student(props) {
    return (
        <div className={classes.box}>
            <p><strong>Name :: </strong> {props.Name}</p>            
            <p><strong>Phone No :: </strong> {props.PN}</p>            
            <p><strong>Branch :: </strong> {props.Branch}</p>            
        </div>
    )
}

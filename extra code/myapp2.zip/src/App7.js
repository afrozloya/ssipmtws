import React, { Component } from 'react'
import axios from 'axios'

export default class App7 extends Component {
    state = {
        title: 'def title',
        body: 'def body.....'
    }
    onChangeHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    onClkHand = (e) => { 
        const url = "https://jsonplaceholder.typicode.com/posts";
        const data = {
            userId: 10,
            title: this.state.title,
            body: this.state.body
        }
        axios.post(url, data)
        .then( resp => {
            console.log(resp.data)
        })
        .catch(err => {
            console.log(err)
        })
    }
    render() {
        return (
            <div>
                <h1>Add New Todo</h1>
                <input name="title"
                value={this.state.title}
                onChange={this.onChangeHand}
                />
                <input name="body"
                value={this.state.body}
                onChange={this.onChangeHand}
                />
                <button onClick={this.onClkHand}>Add</button>
            </div>
        )
    }
}

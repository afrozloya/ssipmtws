import React, { Component } from 'react'

export default class Contact extends Component {
    render() {
        return (
            <div>
                <h1>I am contact page</h1>
            </div>
        )
    }
}

import React, { Component } from 'react'
import About from './About'
import Home from './Home'
import Contact from './Contact'
import {BrowserRouter, NavLink} from 'react-router-dom'
import {Route, Switch, Redirect} from 'react-router'

export default class Main extends Component {
    render() {
        return (
            <BrowserRouter>
                <h1>Bla bla</h1>
                <NavLink to="/home">Home</NavLink>
                {' '}
                <NavLink to="/about">About</NavLink>
                {' '}
                <NavLink to="/contact">Contact</NavLink>
                <Switch>
                <Route path="/about" component={About} />
                <Route path="/contact" component={Contact} />
                <Route path="/home" component={Home} />
                <Redirect to="/home" />
                </Switch>
            </BrowserRouter>
        )
    }
}

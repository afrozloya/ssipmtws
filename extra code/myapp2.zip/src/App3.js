import React from 'react'
import axios from 'axios'

export default class App extends React.Component {

  componentDidMount(){
    // // const url = "https://jsonplaceholder.typicode.com/posts";
    // const url = "https://jsonplaceholder.typicode.com/posts/2";
    // axios.get(url)
    // .then(resp => {
    //   console.log(resp.data);
    // })    
    // .catch(err => {
    //   console.log(err);
    // })

    const url = "https://jsonplaceholder.typicode.com/posts";
    const data = {
      "userId": 1,
      "title": "insert testing....",
      "body": "i want to give you code to insert also...."
    }
    const header = {
      headers: {
        'Authorization': `Basic 898989kkk8988`
      }
    }
    axios.post(url, data, header)
    .then(resp => {
      console.log(resp);
      console.log(resp.data);
    })    
    .catch(err => {
      console.log(err);
    })

  }

  render() {
    return (
      <div>
        <h1>New!!</h1>        
      </div>
    )
  }
}

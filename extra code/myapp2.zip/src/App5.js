import React from 'react'
import axios from 'axios'

export default class App extends React.Component {

  componentDidMount(){
    const url = "https://jsonplaceholder.typicode.com/posts/2";
    const data = {
      "userId": 8,
      "title": "SSIPMT bla bla bla",
      "body": "Raipur.........."
    }
    axios.put(url, data)
    .then(resp => {
      console.log(resp.data);
    })    
    .catch(err => {
      console.log(err);
    })

  }

  render() {
    return (
      <div>
        <h1>New!!</h1>        
      </div>
    )
  }
}

import React, { Component } from 'react'
import Login from './Login'
import Signup from './Signup'

export default class Main2 extends Component {
    state = {
        token: null
    }
    setToken = (token) => {
        this.setState({
            token: token
        })
    }
    render() {
        let out = <div>
               <Login  setToken={this.setToken} />
               <Signup />
        </div>
        if(this.state.token){
            out =<h1>Welcome!!!!</h1>
        }
        return (
            <div>
               <h1>I am new </h1> 
               {out}
            </div>
        )
    }
}

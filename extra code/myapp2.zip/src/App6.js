import React from 'react'
import axios from 'axios'
export default class App extends React.Component {
  state = {
    title: 'bla',
    body: ''
  }
  onChangeHand = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }
  onClkHand = () => {
    const url = "https://jsonplaceholder.typicode.com/posts";
    const data = {
      "userId": 1,
      "title": this.state.title,
      "body": this.state.body
    }
    axios.post(url, data)
    .then(resp => {
      console.log(resp);
      console.log(resp.data);
      this.setState({
        title:'',
        body: ''
      })
    })    
    .catch(err => {
      console.log(err);
    })
  }
  render() {
    return (
      <div>
        <h1>New!!</h1> 
        <input name="title" value={this.state.title} 
        onChange={this.onChangeHand}
        />       
        <input name="body" value={this.state.body} 
        onChange={this.onChangeHand}
        />       
        <button onClick={this.onClkHand}>Add</button>
      </div>
    )
  }
}

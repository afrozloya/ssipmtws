import React, { Component } from 'react'
import axios from 'axios'

export default class Login extends Component {
    state = {
        email: '',
        password: ''
    }
    onChangeHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    onClkHand = (e) => { 
        const url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCEX7qvm9PF7PNQVwzzQmNYd2sSp_tew_8";
        
        const data = {
            email: this.state.email,
            password: this.state.password,
            returnSecureToken: true
        }
        axios.post(url, data)
        .then( resp => {
            console.log(resp.data)
            this.props.setToken(resp.data.idToken)
        })
        .catch(err => {
            console.log(err)
        })
    }
    render() {
        return (
            <div>
                <h1>Login</h1>
                <input name="email"
                value={this.state.email}
                type="email"
                onChange={this.onChangeHand}
                />
                <input name="password"
                value={this.state.password}
                type="password"
                onChange={this.onChangeHand}
                />
                <button onClick={this.onClkHand}>Login</button>
            </div>
        )
    }
}

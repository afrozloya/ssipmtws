import React from 'react'
import axios from 'axios'

export default class App4 extends React.Component {

  componentDidMount(){
    const url = "https://jsonplaceholder.typicode.com/posts/2";
    axios.delete(url)
    .then(resp => {
      console.log(resp);
    })    
    .catch(err => {
      console.log(err);
    })
  }

  render() {
    return (
      <div>
        <h1>New!!</h1>        
      </div>
    )
  }
}
